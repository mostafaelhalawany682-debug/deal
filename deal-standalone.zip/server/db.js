'use strict';
const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'deal.db');

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('creator','provider','shop','brand')),
  niche TEXT DEFAULT '',
  provider_category TEXT DEFAULT NULL, -- 'ads' | 'support' (providers only)
  city TEXT DEFAULT '',
  country TEXT DEFAULT 'EG',
  currency TEXT DEFAULT 'EGP',
  contact TEXT NOT NULL UNIQUE,        -- phone or email (login key)
  phone TEXT DEFAULT '',
  followers INTEGER DEFAULT 0,
  price REAL DEFAULT 0,                -- creator/provider listed price
  bio TEXT DEFAULT '',
  links TEXT DEFAULT '',               -- public account links (verification)
  is_platform_founder INTEGER DEFAULT 0,
  is_founder_member INTEGER DEFAULT 0, -- first 100 creators
  verified INTEGER DEFAULT 0,
  pioneer INTEGER DEFAULT 0,           -- first verified in city+niche
  boost_until INTEGER DEFAULT 0,       -- epoch ms
  penalty_level TEXT DEFAULT 'none',   -- none | warning | suspended
  frozen INTEGER DEFAULT 0,
  banned INTEGER DEFAULT 0,
  verify_code TEXT DEFAULT '',
  verify_status TEXT DEFAULT 'none',   -- none|pending|verified|rejected|exceptional
  verify_reason TEXT DEFAULT '',
  verify_url TEXT DEFAULT '',
  min_price_pref REAL DEFAULT 0,
  notify_pref TEXT DEFAULT 'whatsapp',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS shop_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shop_user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  niche TEXT DEFAULT '',
  city TEXT DEFAULT '',
  budget REAL DEFAULT 0,
  currency TEXT DEFAULT 'EGP',
  details TEXT DEFAULT '',
  status TEXT DEFAULT 'open',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  brand_user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  brief TEXT DEFAULT '',
  niche TEXT DEFAULT '',
  city TEXT DEFAULT '',
  budget REAL DEFAULT 0,
  currency TEXT DEFAULT 'EGP',
  status TEXT DEFAULT 'open',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS campaign_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id INTEGER NOT NULL,
  creator_id INTEGER NOT NULL,
  pitch TEXT DEFAULT '',
  status TEXT DEFAULT 'pending',  -- pending|accepted|rejected
  booking_id INTEGER DEFAULT NULL,
  created_at INTEGER NOT NULL,
  UNIQUE(campaign_id, creator_id)
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL,     -- shop/brand user who pays
  talent_id INTEGER NOT NULL,     -- creator/provider user who executes
  source TEXT DEFAULT 'direct',   -- direct|request|campaign|service
  ref_id INTEGER DEFAULT NULL,
  title TEXT DEFAULT '',
  price REAL NOT NULL,
  currency TEXT DEFAULT 'EGP',
  status TEXT DEFAULT 'pending_agreement',
  -- pending_agreement -> awaiting_fee -> awaiting_deposit -> in_progress
  -- -> proof_submitted -> awaiting_rest -> completed ; disputed | cancelled
  agreed_client INTEGER DEFAULT 0,
  agreed_talent INTEGER DEFAULT 0,
  fee_status TEXT DEFAULT 'none', -- none|confirmed|rejected
  fee_ref TEXT DEFAULT '',
  fee_confirmed_at INTEGER DEFAULT 0,
  prev_status TEXT DEFAULT '',
  deadline INTEGER DEFAULT 0,
  proof_url TEXT DEFAULT '',
  proof_at INTEGER DEFAULT 0,
  proof_check TEXT DEFAULT '',    -- verified | failed
  created_at INTEGER NOT NULL,
  completed_at INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL,
  kind TEXT NOT NULL,             -- fee | deposit | rest
  amount REAL NOT NULL,
  ref TEXT DEFAULT '',
  status TEXT DEFAULT 'confirmed',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS disputes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL,
  opened_by INTEGER NOT NULL,
  reason TEXT DEFAULT '',
  status TEXT DEFAULT 'open',     -- open | resolved
  resolution TEXT DEFAULT '',
  created_at INTEGER NOT NULL,
  resolved_at INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL,
  reviewer_id INTEGER NOT NULL,
  reviewee_id INTEGER NOT NULL,
  sentiment TEXT NOT NULL CHECK(sentiment IN ('positive','negative')),
  stars INTEGER DEFAULT 5,
  comment TEXT DEFAULT '',
  created_at INTEGER NOT NULL,
  UNIQUE(booking_id, reviewer_id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT DEFAULT '',
  text TEXT NOT NULL,
  ref TEXT DEFAULT '',
  is_read INTEGER DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS profile_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  talent_id INTEGER NOT NULL,
  viewer_id INTEGER DEFAULT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS badge_state (
  user_id INTEGER NOT NULL,
  badge_key TEXT NOT NULL,
  earned INTEGER DEFAULT 0,
  PRIMARY KEY(user_id, badge_key)
);
`);

module.exports = { db, DB_PATH };
