'use strict';
/**
 * Deal — standalone server (Express + node:sqlite).
 * Business rules mirror the Muse Space version (sbwnsr):
 * commission-first P2P bookings, automatic verification, computed badges,
 * graduated penalties, opportunities matching, owner dashboard.
 */
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { db } = require('./db');

const PORT = process.env.PORT || 3000;
const COMMISSION_RATE = 0.10;
const COMMISSION_PHONE = process.env.COMMISSION_PHONE || '01014388520'; // server-side only
const FEE_REVIEW_WINDOW_MS = 48 * 3600 * 1000;
const RECEIPT_AUTO_CONFIRM_MS = 48 * 3600 * 1000;

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'] }));

const now = () => Date.now();
const rnd = (n) => crypto.randomBytes(n).toString('hex');

/* ---------------- helpers ---------------- */
function notify(userId, type, text, ref = '') {
  db.prepare('INSERT INTO notifications (user_id,type,text,ref,created_at) VALUES (?,?,?,?,?)')
    .run(userId, type, text, ref, now());
}
function getUser(id) { return db.prepare('SELECT * FROM users WHERE id=?').get(id); }

function publicUser(u, viewerId = null) {
  if (!u) return null;
  const stats = talentStats(u.id);
  return {
    id: u.id, name: u.name, role: u.role, niche: u.niche,
    provider_category: u.provider_category, city: u.city, country: u.country,
    currency: u.currency, followers: u.followers, price: u.price, bio: u.bio,
    is_platform_founder: !!u.is_platform_founder,
    is_founder_member: !!u.is_founder_member,
    verified: !!u.verified, pioneer: !!u.pioneer,
    boost_active: u.boost_until > now() && u.penalty_level !== 'suspended',
    member_since: u.created_at,
    completion_rate: stats.completion_rate,
    completed_deals: stats.completed_deals,
    positive_pct: stats.positive_pct,
    avg_stars: stats.avg_stars,
    badges: computeBadges(u.id).filter(b => b.earned).slice(0, 3).map(b => b.key),
    portfolio: portfolioOf(u.id),
    frozen: !!u.frozen, penalty_level: u.penalty_level,
  };
}

function portfolioOf(userId) {
  return db.prepare(`SELECT proof_url FROM bookings WHERE talent_id=? AND status='completed' AND proof_url!='' ORDER BY completed_at DESC LIMIT 12`)
    .all(userId).map(r => r.proof_url);
}

function talentStats(userId) {
  const total = db.prepare(`SELECT COUNT(*) c FROM bookings WHERE talent_id=? AND status NOT IN ('cancelled')`).get(userId).c;
  const completed = db.prepare(`SELECT COUNT(*) c FROM bookings WHERE talent_id=? AND status='completed'`).get(userId).c;
  const rev = db.prepare(`SELECT COUNT(*) c, SUM(CASE WHEN sentiment='positive' THEN 1 ELSE 0 END) pos, AVG(stars) avg FROM reviews WHERE reviewee_id=?`).get(userId);
  return {
    total_deals: total,
    completed_deals: completed,
    completion_rate: total ? Math.round((completed / total) * 100) : 100,
    positive_pct: rev.c ? Math.round((rev.pos / rev.c) * 100) : null,
    avg_stars: rev.avg ? Math.round(rev.avg * 10) / 10 : null,
    reviews_count: rev.c,
  };
}

/* ---------------- badges (computed from the record) ---------------- */
const BADGE_DEFS = [
  { key: 'perfect',   name: 'إتمام مثالي',   color: '#0e9f6e' },
  { key: 'top_rated', name: 'الأعلى تقييماً', color: '#d4a017' },
  { key: 'fast',      name: 'تنفيذ سريع',     color: '#e8720c' },
  { key: 'rising',    name: 'صانع صاعد',      color: '#2f9e44' },
  { key: 'ambassador',name: 'سفير Deal',      color: '#7048c9' },
  { key: 'veteran',   name: 'مخضرم',          color: '#1098ad' },
];
function computeBadges(userId) {
  const u = getUser(userId);
  const s = talentStats(userId);
  const lastProofs = db.prepare(`SELECT proof_at, deadline FROM bookings WHERE talent_id=? AND status='completed' AND proof_at>0 ORDER BY completed_at DESC LIMIT 5`).all(userId);
  const onTime = lastProofs.length === 5 && lastProofs.every(p => !p.deadline || p.proof_at <= p.deadline);
  const invitedDone = 0; // referrals tracked in Muse version via invite codes; standalone keeps hook (see README)
  const ageMs = now() - u.created_at;
  const defs = {
    perfect:    { earned: s.completed_deals >= 10 && s.completion_rate === 100, progress: `${Math.min(s.completed_deals,10)}/10 صفقات بإتمام 100%` },
    top_rated:  { earned: s.reviews_count >= 10 && s.positive_pct >= 95, progress: `${Math.min(s.reviews_count,10)}/10 تقييمات بإيجابية 95%+` },
    fast:       { earned: onTime, progress: `${lastProofs.filter(p => !p.deadline || p.proof_at <= p.deadline).length}/5 إثباتات قبل المهلة` },
    rising:     { earned: s.completed_deals >= 5, progress: `${Math.min(s.completed_deals,5)}/5 صفقات` },
    ambassador: { earned: invitedDone >= 5, progress: `${invitedDone}/5 مدعوين أكملوا صفقة` },
    veteran:    { earned: ageMs >= 180 * 24 * 3600 * 1000 && s.completed_deals >= 20, progress: `${Math.min(s.completed_deals,20)}/20 صفقة + 6 أشهر عضوية` },
  };
  return BADGE_DEFS.map(d => ({ ...d, ...defs[d.key] }));
}
function syncBadges(userId) {
  const badges = computeBadges(userId);
  for (const b of badges) {
    const row = db.prepare('SELECT earned FROM badge_state WHERE user_id=? AND badge_key=?').get(userId, b.key);
    const prev = row ? row.earned : 0;
    if (b.earned && !prev) notify(userId, 'badge', `شارة جديدة: ${b.name}`, `badge:${b.key}`);
    if (!b.earned && prev) notify(userId, 'badge_lost', `سُحبت شارة: ${b.name}`, `badge:${b.key}`);
    db.prepare('INSERT INTO badge_state (user_id,badge_key,earned) VALUES (?,?,?) ON CONFLICT(user_id,badge_key) DO UPDATE SET earned=excluded.earned')
      .run(userId, b.key, b.earned ? 1 : 0);
  }
}

/* ---------------- penalties (automatic, graduated) ---------------- */
function applyPenalties(userId) {
  const neg = db.prepare(`SELECT COUNT(*) c FROM reviews WHERE reviewee_id=? AND sentiment='negative'`).get(userId).c;
  const u = getUser(userId);
  let level = 'none';
  if (neg >= 5) level = 'suspended'; else if (neg >= 3) level = 'warning';
  if (level !== u.penalty_level && !u.banned) {
    const frozen = level === 'suspended' ? 1 : u.frozen;
    db.prepare('UPDATE users SET penalty_level=?, frozen=? WHERE id=?').run(level, frozen, userId);
    if (level === 'warning') notify(userId, 'penalty', 'تنبيه: تراكمت لديك 3 تقييمات سلبية', '');
    if (level === 'suspended') notify(userId, 'penalty', 'تم تعليق حسابك وتجميد رصيدك داخل التطبيق بسبب 5 تقييمات سلبية', '');
  }
}

/* ---------------- auth ---------------- */
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const s = token && db.prepare('SELECT * FROM sessions WHERE token=?').get(token);
  if (!s) return res.status(401).json({ error: 'سجل الدخول أولاً' });
  req.user = getUser(s.user_id);
  if (!req.user) return res.status(401).json({ error: 'حساب غير موجود' });
  if (req.user.banned) return res.status(403).json({ error: 'هذا الحساب محظور' });
  next();
}
function makeSession(userId) {
  const token = rnd(24);
  db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)').run(token, userId, now());
  return token;
}

app.post('/api/auth/register', (req, res) => {
  const { name, role, niche = '', provider_category = null, city = '', country = 'EG', currency = 'EGP', contact, phone = '', followers = 0, price = 0, bio = '', links = '' } = req.body || {};
  if (!name || !role || !contact) return res.status(400).json({ error: 'الاسم والدور ووسيلة التواصل مطلوبة' });
  if (!['creator', 'provider', 'shop', 'brand'].includes(role)) return res.status(400).json({ error: 'دور غير صحيح' });
  if (role === 'provider' && !['ads', 'support'].includes(provider_category)) return res.status(400).json({ error: 'اختر فئة الخدمة: إعلانات ممولة أو حلول حسابات' });
  if (db.prepare('SELECT id FROM users WHERE contact=?').get(contact)) return res.status(409).json({ error: 'وسيلة التواصل مسجلة من قبل — سجل الدخول' });

  const totalUsers = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  const creatorsCount = db.prepare(`SELECT COUNT(*) c FROM users WHERE role='creator'`).get().c;
  const isFounder = totalUsers === 0 ? 1 : 0;
  const isFounderMember = role === 'creator' && creatorsCount < 100 ? 1 : 0;
  const info = db.prepare(`INSERT INTO users (name,role,niche,provider_category,city,country,currency,contact,phone,followers,price,bio,links,is_platform_founder,is_founder_member,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(name, role, niche, provider_category, city, country, currency, contact, phone || contact, followers, price, bio, links, isFounder, isFounderMember, now());
  const user = getUser(info.lastInsertRowid);
  res.json({ token: makeSession(user.id), user: publicUser(user) });
});

app.post('/api/auth/login', (req, res) => {
  const { contact } = req.body || {};
  const user = contact && db.prepare('SELECT * FROM users WHERE contact=?').get(contact);
  if (!user) return res.status(404).json({ error: 'لا يوجد حساب بهذه البيانات — سجل أولاً' });
  if (user.banned) return res.status(403).json({ error: 'هذا الحساب محظور' });
  res.json({ token: makeSession(user.id), user: publicUser(user) });
});

app.get('/api/me', auth, (req, res) => {
  syncBadges(req.user.id);
  res.json({ user: publicUser(req.user, req.user.id), verify_status: req.user.verify_status, verify_code: req.user.verify_code });
});

app.post('/api/me/prefs', auth, (req, res) => {
  const { min_price_pref, notify_pref } = req.body || {};
  db.prepare('UPDATE users SET min_price_pref=COALESCE(?,min_price_pref), notify_pref=COALESCE(?,notify_pref) WHERE id=?')
    .run(min_price_pref ?? null, notify_pref ?? null, req.user.id);
  res.json({ ok: true });
});

/* ---------------- directory / market ---------------- */
app.get('/api/directory', (req, res) => {
  const { role, niche, city, q } = req.query;
  let sql = `SELECT * FROM users WHERE role IN ('creator','provider') AND banned=0`;
  const args = [];
  if (role) { sql += ' AND role=?'; args.push(role); }
  if (niche) { sql += ' AND niche=?'; args.push(niche); }
  if (city) { sql += ' AND city=?'; args.push(city); }
  if (q) { sql += ' AND (name LIKE ? OR niche LIKE ? OR city LIKE ?)'; args.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  const rows = db.prepare(sql).all(...args);
  const t = now();
  rows.sort((a, b) => {
    const boost = (x) => (x.boost_until > t && x.penalty_level !== 'suspended') ? 1 : 0;
    return (b.verified - a.verified) || (boost(b) - boost(a)) || (talentStats(b.id).completed_deals - talentStats(a.id).completed_deals);
  });
  res.json({ items: rows.map(u => publicUser(u)) });
});

app.get('/api/talent/:id', (req, res) => {
  const u = getUser(+req.params.id);
  if (!u) return res.status(404).json({ error: 'غير موجود' });
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const s = token && db.prepare('SELECT * FROM sessions WHERE token=?').get(token);
  const viewerId = s ? s.user_id : null;
  if (viewerId !== u.id) db.prepare('INSERT INTO profile_views (talent_id,viewer_id,created_at) VALUES (?,?,?)').run(u.id, viewerId, now());
  const reviews = db.prepare(`SELECT r.*, u2.name reviewer_name FROM reviews r JOIN users u2 ON u2.id=r.reviewer_id WHERE r.reviewee_id=? ORDER BY r.created_at DESC LIMIT 10`).all(u.id);
  res.json({ user: publicUser(u), stats: talentStats(u.id), badges: computeBadges(u.id), reviews });
});

/* ---------------- automatic verification ---------------- */
app.post('/api/verify/request', auth, (req, res) => {
  if (req.user.role !== 'creator') return res.status(400).json({ error: 'التوثيق للصناع فقط' });
  const code = `DEAL-${req.user.id}-${rnd(3).toUpperCase()}`;
  db.prepare(`UPDATE users SET verify_code=?, verify_status='pending', verify_reason='' WHERE id=?`).run(code, req.user.id);
  res.json({ code, instructions: 'ضع هذا الكود في بايو أحد حساباتك العلنية أو منشور مثبت، ثم أرسل رابط الحساب للفحص.' });
});

app.post('/api/verify/check', auth, async (req, res) => {
  const { url } = req.body || {};
  const u = req.user;
  if (!u.verify_code) return res.status(400).json({ error: 'اطلب كود التوثيق أولاً' });
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'رابط غير صحيح' });
  let html = null, fetchErr = '';
  try {
    const r = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0 (DealVerify)' }, redirect: 'follow', signal: AbortSignal.timeout(12000) });
    if (!r.ok) fetchErr = `HTTP ${r.status}`;
    else html = await r.text();
  } catch (e) { fetchErr = e.message; }

  if (html === null) {
    db.prepare(`UPDATE users SET verify_status='exceptional', verify_url=?, verify_reason=? WHERE id=?`)
      .run(url, `تعذرت قراءة الصفحة آلياً (${fetchErr}) — تحتاج مراجعة استثنائية`, u.id);
    const founder = db.prepare('SELECT id FROM users WHERE is_platform_founder=1').get();
    if (founder) notify(founder.id, 'verify_exceptional', `طلب توثيق استثنائي من ${u.name}`, `user:${u.id}`);
    notify(u.id, 'verification', 'توثيقك في «مراجعة استثنائية» — تعذرت القراءة الآلية لصفحتك', '');
    return res.json({ status: 'exceptional' });
  }
  const hasCode = html.includes(u.verify_code);
  const nameMatch = html.toLowerCase().includes(u.name.toLowerCase()) || html.toLowerCase().includes(u.name.split(' ')[0].toLowerCase());
  if (hasCode && nameMatch) {
    const pioneer = db.prepare(`SELECT id FROM users WHERE verified=1 AND pioneer=1 AND city=? AND niche=?`).get(u.city, u.niche) ? 0 : 1;
    db.prepare(`UPDATE users SET verified=1, verify_status='verified', verify_reason='', pioneer=?, boost_until=? WHERE id=?`)
      .run(pioneer, now() + 7 * 24 * 3600 * 1000, u.id);
    notify(u.id, 'verification', 'مبروك! حسابك بقى «موثّق Deal»' + (pioneer ? ' وأنت «رائد المدينة» في مجالك' : ''), '');
    return res.json({ status: 'verified', pioneer: !!pioneer });
  }
  const reason = !hasCode ? 'كود الملكية غير موجود في الصفحة' : 'اسم الحساب لا يطابق اسم التسجيل';
  db.prepare(`UPDATE users SET verify_status='rejected', verify_url=?, verify_reason=? WHERE id=?`).run(url, reason, u.id);
  res.json({ status: 'rejected', reason });
});

/* ---------------- bookings (commission-first P2P) ---------------- */
function getBooking(id) { return db.prepare('SELECT * FROM bookings WHERE id=?').get(id); }
function bookingView(b, viewer) {
  const fee = Math.round(b.price * COMMISSION_RATE * 100) / 100;
  const net = b.price - fee;
  const myReview = viewer ? db.prepare('SELECT * FROM reviews WHERE booking_id=? AND reviewer_id=?').get(b.id, viewer.id) : null;
  return {
    ...b,
    fee, net, deposit: Math.round(net / 2 * 100) / 100, rest: Math.round(net / 2 * 100) / 100,
    client: publicUser(getUser(b.client_id)), talent: publicUser(getUser(b.talent_id)),
    my_review: myReview || null,
    can_review: b.status === 'completed' && viewer && !myReview && (viewer.id === b.client_id || viewer.id === b.talent_id),
    alternatives: b.status === 'disputed' ? verifiedAlternatives(b) : [],
  };
}
function verifiedAlternatives(b) {
  const t = getUser(b.talent_id);
  return db.prepare(`SELECT * FROM users WHERE role=? AND niche=? AND city=? AND verified=1 AND id!=? AND banned=0 LIMIT 3`)
    .all(t.role, t.niche, t.city, t.id).map(u => publicUser(u));
}
function sweepAutoConfirm() {
  const due = db.prepare(`SELECT * FROM bookings WHERE status='proof_submitted' AND proof_check='verified' AND proof_at>0 AND ? - proof_at >= ?`)
    .all(now(), RECEIPT_AUTO_CONFIRM_MS);
  for (const b of due) {
    db.prepare(`UPDATE bookings SET status='awaiting_rest' WHERE id=?`).run(b.id);
    notify(b.client_id, 'booking', `حجز #${b.id}: تأكد الاستلام تلقائياً بعد 48 ساعة — ادفع الباقي`, `booking:${b.id}`);
    notify(b.talent_id, 'booking', `حجز #${b.id}: تأكد الاستلام تلقائياً — الباقي في الطريق`, `booking:${b.id}`);
  }
}

app.post('/api/bookings', auth, (req, res) => {
  const { talent_id, title = '', price, source = 'direct', ref_id = null, deadline_days = 7 } = req.body || {};
  const talent = getUser(+talent_id);
  if (!talent || !['creator', 'provider'].includes(talent.role)) return res.status(400).json({ error: 'المنفذ غير صحيح' });
  if (talent.id === req.user.id) return res.status(400).json({ error: 'لا يمكنك حجز نفسك' });
  if (talent.penalty_level === 'suspended' || talent.frozen) return res.status(403).json({ error: 'هذا الحساب معلّق حالياً ولا يستقبل حجوزات' });
  const p = price != null ? +price : talent.price;
  if (!p || p <= 0) return res.status(400).json({ error: 'حدد سعراً صحيحاً' });
  const info = db.prepare(`INSERT INTO bookings (client_id,talent_id,source,ref_id,title,price,currency,deadline,created_at) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(req.user.id, talent.id, source, ref_id, title || `حجز مع ${talent.name}`, p, talent.currency, now() + deadline_days * 24 * 3600 * 1000, now());
  notify(talent.id, 'booking_new', `طلب حجز جديد #${info.lastInsertRowid} بقيمة ${p} ${talent.currency}`, `booking:${info.lastInsertRowid}`);
  res.json({ booking: bookingView(getBooking(info.lastInsertRowid), req.user) });
});

app.get('/api/bookings', auth, (req, res) => {
  sweepAutoConfirm();
  const rows = db.prepare('SELECT * FROM bookings WHERE client_id=? OR talent_id=? ORDER BY created_at DESC').all(req.user.id, req.user.id);
  res.json({ items: rows.map(b => bookingView(b, req.user)) });
});

app.get('/api/bookings/:id', auth, (req, res) => {
  sweepAutoConfirm();
  const b = getBooking(+req.params.id);
  if (!b || (b.client_id !== req.user.id && b.talent_id !== req.user.id && !req.user.is_platform_founder)) return res.status(404).json({ error: 'غير موجود' });
  res.json({ booking: bookingView(b, req.user) });
});

app.post('/api/bookings/:id/agree', auth, (req, res) => {
  let b = getBooking(+req.params.id);
  if (!b) return res.status(404).json({ error: 'غير موجود' });
  if (b.status !== 'pending_agreement') return res.status(400).json({ error: 'الحجز تجاوز مرحلة الاتفاق' });
  if (req.user.id === b.client_id) db.prepare('UPDATE bookings SET agreed_client=1 WHERE id=?').run(b.id);
  else if (req.user.id === b.talent_id) db.prepare('UPDATE bookings SET agreed_talent=1 WHERE id=?').run(b.id);
  else return res.status(403).json({ error: 'لست طرفاً في الحجز' });
  b = getBooking(b.id);
  if (b.agreed_client && b.agreed_talent) {
    db.prepare(`UPDATE bookings SET status='awaiting_fee' WHERE id=?`).run(b.id);
    notify(b.client_id, 'booking', `حجز #${b.id}: اتفق الطرفان — خطوة العمولة أولاً`, `booking:${b.id}`);
    notify(b.talent_id, 'booking', `حجز #${b.id}: اتفق الطرفان — في انتظار تأكيد عمولة Deal`, `booking:${b.id}`);
  }
  res.json({ booking: bookingView(getBooking(b.id), req.user) });
});

/** Commission number: ONLY to the paying client, ONLY at the fee step of a confirmed booking. */
app.get('/api/bookings/:id/fee-info', auth, (req, res) => {
  const b = getBooking(+req.params.id);
  if (!b || b.client_id !== req.user.id) return res.status(403).json({ error: 'غير متاح' });
  if (b.status !== 'awaiting_fee' || b.fee_status === 'confirmed') return res.status(400).json({ error: 'خطوة العمولة غير مفتوحة الآن' });
  res.json({ label: 'Deal — حساب عمولات التطبيق', phone: COMMISSION_PHONE, methods: ['Vodafone Cash', 'InstaPay'], amount: Math.round(b.price * COMMISSION_RATE * 100) / 100, currency: b.currency });
});

app.post('/api/bookings/:id/pay', auth, (req, res) => {
  const { kind, ref } = req.body || {};
  let b = getBooking(+req.params.id);
  if (!b || b.client_id !== req.user.id) return res.status(403).json({ error: 'الدفع من العميل فقط' });
  if (!ref) return res.status(400).json({ error: 'مرجع العملية مطلوب' });
  const fee = Math.round(b.price * COMMISSION_RATE * 100) / 100;
  const net = b.price - fee, half = Math.round(net / 2 * 100) / 100;

  if (kind === 'fee') {
    if (b.status !== 'awaiting_fee') return res.status(400).json({ error: 'خطوة العمولة ليست مفتوحة' });
    db.prepare('INSERT INTO payments (booking_id,kind,amount,ref,status,created_at) VALUES (?,?,?,?,?,?)').run(b.id, 'fee', fee, ref, 'confirmed', now());
    db.prepare(`UPDATE bookings SET fee_status='confirmed', fee_ref=?, fee_confirmed_at=?, status='awaiting_deposit' WHERE id=?`).run(ref, now(), b.id);
    notify(b.talent_id, 'booking', `حجز #${b.id}: تأكدت عمولة Deal — العربون اتفتح`, `booking:${b.id}`);
  } else if (kind === 'deposit') {
    if (b.status !== 'awaiting_deposit') return res.status(400).json({ error: 'العربون غير مفتوح الآن' });
    db.prepare('INSERT INTO payments (booking_id,kind,amount,ref,status,created_at) VALUES (?,?,?,?,?,?)').run(b.id, 'deposit', half, ref, 'confirmed', now());
    db.prepare(`UPDATE bookings SET status='in_progress' WHERE id=?`).run(b.id);
    notify(b.talent_id, 'booking', `حجز #${b.id}: وصلك العربون ${half} — ابدأ التنفيذ`, `booking:${b.id}`);
  } else if (kind === 'rest') {
    if (b.status !== 'awaiting_rest') return res.status(400).json({ error: 'الباقي غير مفتوح الآن' });
    db.prepare('INSERT INTO payments (booking_id,kind,amount,ref,status,created_at) VALUES (?,?,?,?,?,?)').run(b.id, 'rest', half, ref, 'confirmed', now());
    db.prepare(`UPDATE bookings SET status='completed', completed_at=? WHERE id=?`).run(now(), b.id);
    notify(b.talent_id, 'booking', `حجز #${b.id}: اكتمل القبض — قيّم تجربتك`, `booking:${b.id}`);
    notify(b.client_id, 'booking', `حجز #${b.id}: اكتمل — قيّم المنفذ`, `booking:${b.id}`);
    syncBadges(b.talent_id);
  } else return res.status(400).json({ error: 'نوع دفعة غير صحيح' });
  res.json({ booking: bookingView(getBooking(b.id), req.user) });
});

app.post('/api/bookings/:id/proof', auth, async (req, res) => {
  const { url } = req.body || {};
  const b = getBooking(+req.params.id);
  if (!b || b.talent_id !== req.user.id) return res.status(403).json({ error: 'الإثبات من المنفذ فقط' });
  if (b.status !== 'in_progress') return res.status(400).json({ error: 'الحجز ليس في مرحلة التنفيذ' });
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).json({ error: 'رابط غير صحيح' });
  let ok = false;
  try {
    const r = await fetch(url, { method: 'GET', headers: { 'user-agent': 'Mozilla/5.0 (DealProof)' }, redirect: 'follow', signal: AbortSignal.timeout(12000) });
    ok = r.status === 200;
  } catch (e) { ok = false; }
  if (!ok) return res.status(400).json({ error: 'تعذر التحقق: الرابط لا يعمل أو غير علني (لازم HTTP 200)' });
  db.prepare(`UPDATE bookings SET proof_url=?, proof_at=?, proof_check='verified', status='proof_submitted' WHERE id=?`).run(url, now(), b.id);
  notify(b.client_id, 'booking', `حجز #${b.id}: المنفذ قدم إثبات التنفيذ — أكد الاستلام`, `booking:${b.id}`);
  res.json({ booking: bookingView(getBooking(b.id), req.user) });
});

app.post('/api/bookings/:id/confirm-receipt', auth, (req, res) => {
  const b = getBooking(+req.params.id);
  if (!b || b.client_id !== req.user.id) return res.status(403).json({ error: 'التأكيد من العميل فقط' });
  if (b.status !== 'proof_submitted') return res.status(400).json({ error: 'لا يوجد إثبات بانتظار التأكيد' });
  db.prepare(`UPDATE bookings SET status='awaiting_rest' WHERE id=?`).run(b.id);
  notify(b.talent_id, 'booking', `حجز #${b.id}: العميل أكد الاستلام — الباقي اتفتح`, `booking:${b.id}`);
  res.json({ booking: bookingView(getBooking(b.id), req.user) });
});

app.post('/api/bookings/:id/dispute', auth, (req, res) => {
  const { reason = '' } = req.body || {};
  const b = getBooking(+req.params.id);
  if (!b || (b.client_id !== req.user.id && b.talent_id !== req.user.id)) return res.status(403).json({ error: 'لست طرفاً' });
  if (['completed', 'cancelled', 'disputed'].includes(b.status)) return res.status(400).json({ error: 'لا يمكن فتح نزاع الآن' });
  const info = db.prepare('INSERT INTO disputes (booking_id,opened_by,reason,created_at) VALUES (?,?,?,?)').run(b.id, req.user.id, reason, now());
  db.prepare(`UPDATE bookings SET prev_status=status, status='disputed' WHERE id=?`).run(b.id);
  const founder = db.prepare('SELECT id FROM users WHERE is_platform_founder=1').get();
  if (founder) notify(founder.id, 'dispute', `نزاع جديد على حجز #${b.id}`, `booking:${b.id}`);
  res.json({ dispute_id: info.lastInsertRowid, alternatives: verifiedAlternatives(b) });
});

/* ---------------- reviews ---------------- */
app.post('/api/bookings/:id/review', auth, (req, res) => {
  const { sentiment, stars = 5, comment = '' } = req.body || {};
  const b = getBooking(+req.params.id);
  if (!b) return res.status(404).json({ error: 'غير موجود' });
  if (b.status !== 'completed') return res.status(400).json({ error: 'التقييم بعد اكتمال القبض فقط' });
  if (req.user.id !== b.client_id && req.user.id !== b.talent_id) return res.status(403).json({ error: 'لست طرفاً' });
  if (!['positive', 'negative'].includes(sentiment)) return res.status(400).json({ error: 'اختر إيجابي أو سلبي' });
  const reviewee = req.user.id === b.client_id ? b.talent_id : b.client_id;
  try {
    db.prepare('INSERT INTO reviews (booking_id,reviewer_id,reviewee_id,sentiment,stars,comment,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(b.id, req.user.id, reviewee, sentiment, Math.min(5, Math.max(1, stars)), comment, now());
  } catch (e) { return res.status(409).json({ error: 'قيّمت هذا الحجز من قبل — التقييم لا يُعدّل' }); }
  applyPenalties(reviewee);
  syncBadges(reviewee);
  res.json({ ok: true });
});

/* ---------------- shop requests + opportunities ---------------- */
app.post('/api/requests', auth, (req, res) => {
  const { title, niche = '', city = '', budget = 0, currency = 'EGP', details = '' } = req.body || {};
  if (!title) return res.status(400).json({ error: 'عنوان الطلب مطلوب' });
  const info = db.prepare('INSERT INTO shop_requests (shop_user_id,title,niche,city,budget,currency,details,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(req.user.id, title, niche, city || req.user.city, budget, currency, details, now());
  res.json({ id: info.lastInsertRowid });
});
app.get('/api/requests', (req, res) => {
  const rows = db.prepare(`SELECT r.*, u.name shop_name FROM shop_requests r JOIN users u ON u.id=r.shop_user_id WHERE r.status='open' ORDER BY r.created_at DESC`).all();
  res.json({ items: rows });
});

function matchScore(creator, item) {
  let score = 0; const reasons = [];
  if (item.city && creator.city && item.city === creator.city) { score += 40; reasons.push('نفس المدينة'); }
  if (item.niche && creator.niche && item.niche === creator.niche) { score += 40; reasons.push('نفس المجال'); }
  const minOk = !creator.min_price_pref || (item.budget || 0) >= creator.min_price_pref;
  if (minOk && item.budget > 0) { score += 20; reasons.push('الميزانية مناسبة'); }
  return { score, reasons };
}
app.get('/api/opportunities', auth, (req, res) => {
  if (req.user.role !== 'creator') return res.json({ items: [] });
  const reqs = db.prepare(`SELECT * FROM shop_requests WHERE status='open'`).all()
    .map(r => ({ kind: 'request', ...r, ...matchScore(req.user, r) }));
  const camps = db.prepare(`SELECT * FROM campaigns WHERE status='open'`).all()
    .map(c => ({ kind: 'campaign', ...c, ...matchScore(req.user, c) }));
  const items = [...reqs, ...camps].filter(x => x.score > 0).sort((a, b) => b.score - a.score);
  res.json({ items });
});

/* ---------------- campaigns ---------------- */
app.post('/api/campaigns', auth, (req, res) => {
  const { title, brief = '', niche = '', city = '', budget = 0, currency = 'EGP' } = req.body || {};
  if (!title) return res.status(400).json({ error: 'عنوان الحملة مطلوب' });
  const info = db.prepare('INSERT INTO campaigns (brand_user_id,title,brief,niche,city,budget,currency,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(req.user.id, title, brief, niche, city || req.user.city, budget, currency, now());
  res.json({ id: info.lastInsertRowid });
});
app.get('/api/campaigns', (req, res) => {
  const rows = db.prepare(`SELECT c.*, u.name brand_name FROM campaigns c JOIN users u ON u.id=c.brand_user_id WHERE c.status='open' ORDER BY c.created_at DESC`).all();
  res.json({ items: rows });
});
app.post('/api/campaigns/:id/apply', auth, (req, res) => {
  if (req.user.role !== 'creator') return res.status(400).json({ error: 'التقديم للصناع فقط' });
  const { pitch = '' } = req.body || {};
  try {
    const info = db.prepare('INSERT INTO campaign_applications (campaign_id,creator_id,pitch,created_at) VALUES (?,?,?,?)')
      .run(+req.params.id, req.user.id, pitch, now());
    const c = db.prepare('SELECT * FROM campaigns WHERE id=?').get(+req.params.id);
    if (c) notify(c.brand_user_id, 'campaign', `صانع جديد قدم على حملتك «${c.title}»`, `campaign:${c.id}`);
    res.json({ id: info.lastInsertRowid });
  } catch (e) { return res.status(409).json({ error: 'قدمت على هذه الحملة من قبل' }); }
});
app.get('/api/campaigns/:id/applications', auth, (req, res) => {
  const c = db.prepare('SELECT * FROM campaigns WHERE id=?').get(+req.params.id);
  if (!c || c.brand_user_id !== req.user.id) return res.status(403).json({ error: 'ليست حملتك' });
  const rows = db.prepare('SELECT * FROM campaign_applications WHERE campaign_id=? ORDER BY created_at DESC').all(c.id);
  res.json({ items: rows.map(a => ({ ...a, creator: publicUser(getUser(a.creator_id)) })) });
});
app.post('/api/applications/:id/accept', auth, (req, res) => {
  const a = db.prepare('SELECT * FROM campaign_applications WHERE id=?').get(+req.params.id);
  if (!a) return res.status(404).json({ error: 'غير موجود' });
  const c = db.prepare('SELECT * FROM campaigns WHERE id=?').get(a.campaign_id);
  if (!c || c.brand_user_id !== req.user.id) return res.status(403).json({ error: 'ليست حملتك' });
  if (a.status !== 'pending') return res.status(400).json({ error: 'تم البت في هذا التقديم' });
  const info = db.prepare(`INSERT INTO bookings (client_id,talent_id,source,ref_id,title,price,currency,deadline,created_at) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(req.user.id, a.creator_id, 'campaign', c.id, c.title, c.budget || getUser(a.creator_id).price, c.currency, now() + 7 * 24 * 3600 * 1000, now());
  db.prepare(`UPDATE campaign_applications SET status='accepted', booking_id=? WHERE id=?`).run(info.lastInsertRowid, a.id);
  notify(a.creator_id, 'booking_new', `براند «${req.user.name}» قبل تقديمك — حجز #${info.lastInsertRowid} اتفتح`, `booking:${info.lastInsertRowid}`);
  res.json({ booking_id: info.lastInsertRowid });
});

/* ---------------- notifications ---------------- */
app.get('/api/notifications', auth, (req, res) => {
  const items = db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
  const unread = db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0').get(req.user.id).c;
  res.json({ items, unread });
});
app.post('/api/notifications/read', auth, (req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id);
  res.json({ ok: true });
});

/* ---------------- creator stats ---------------- */
app.get('/api/my/stats', auth, (req, res) => {
  const uid = req.user.id;
  const views = db.prepare('SELECT COUNT(*) c FROM profile_views WHERE talent_id=?').get(uid).c;
  const opps = db.prepare(`SELECT COUNT(*) c FROM shop_requests WHERE status='open'`).get().c +
               db.prepare(`SELECT COUNT(*) c FROM campaigns WHERE status='open'`).get().c;
  const myBookings = db.prepare('SELECT COUNT(*) c FROM bookings WHERE talent_id=?').get(uid).c;
  const done = db.prepare(`SELECT COUNT(*) c FROM bookings WHERE talent_id=? AND status='completed'`).get(uid).c;
  const earnings = db.prepare(`SELECT p.kind, p.amount, p.created_at FROM payments p JOIN bookings b ON b.id=p.booking_id WHERE b.talent_id=? AND p.kind IN ('deposit','rest')`).all(uid);
  const byMonth = {};
  for (const e of earnings) {
    const d = new Date(e.created_at); const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    byMonth[k] = (byMonth[k] || 0) + e.amount;
  }
  res.json({ views, opportunities_open: opps, bookings: myBookings, conversion: myBookings ? Math.round(done / myBookings * 100) : 0, earnings_total: earnings.reduce((s, e) => s + e.amount, 0), earnings_by_month: byMonth, record: talentStats(uid) });
});

/* ---------------- owner dashboard (platform founder only) ---------------- */
function ownerOnly(req, res, next) {
  if (!req.user.is_platform_founder) return res.status(403).json({ error: 'لوحة المالك للمؤسس فقط' });
  next();
}
app.get('/api/owner/dashboard', auth, ownerOnly, (req, res) => {
  const fees = db.prepare(`SELECT amount, created_at FROM payments WHERE kind='fee' AND status='confirmed'`).all();
  const dayAgo = now() - 24 * 3600 * 1000;
  const monthAgo = now() - 30 * 24 * 3600 * 1000;
  const commissions = {
    today: fees.filter(f => f.created_at >= dayAgo).reduce((s, f) => s + f.amount, 0),
    month: fees.filter(f => f.created_at >= monthAgo).reduce((s, f) => s + f.amount, 0),
    total: fees.reduce((s, f) => s + f.amount, 0),
  };
  const disputes = db.prepare(`SELECT d.*, b.price, b.currency FROM disputes d JOIN bookings b ON b.id=d.booking_id WHERE d.status='open'`).all();
  const exceptional = db.prepare(`SELECT id,name,city,niche,verify_url,verify_reason FROM users WHERE verify_status='exceptional'`).all();
  const penalized = db.prepare(`SELECT id,name,penalty_level,frozen,banned FROM users WHERE penalty_level!='none' OR frozen=1 OR banned=1`).all();
  const platform = {
    users: db.prepare('SELECT COUNT(*) c FROM users').get().c,
    creators: db.prepare(`SELECT COUNT(*) c FROM users WHERE role='creator'`).get().c,
    verified: db.prepare('SELECT COUNT(*) c FROM users WHERE verified=1').get().c,
    founders: db.prepare('SELECT COUNT(*) c FROM users WHERE is_founder_member=1').get().c,
    bookings: db.prepare('SELECT COUNT(*) c FROM bookings').get().c,
    completed: db.prepare(`SELECT COUNT(*) c FROM bookings WHERE status='completed'`).get().c,
  };
  res.json({ commissions, disputes, exceptional, penalized, platform });
});
app.post('/api/owner/disputes/:id/resolve', auth, ownerOnly, (req, res) => {
  const d = db.prepare('SELECT * FROM disputes WHERE id=?').get(+req.params.id);
  if (!d || d.status !== 'open') return res.status(404).json({ error: 'نزاع غير مفتوح' });
  const { action = 'restore', note = '' } = req.body || {};
  const b = getBooking(d.booking_id);
  const target = action === 'cancel' ? 'cancelled' : (b.prev_status || 'pending_agreement');
  db.prepare('UPDATE bookings SET status=? WHERE id=?').run(target, b.id);
  db.prepare(`UPDATE disputes SET status='resolved', resolution=?, resolved_at=? WHERE id=?`).run(note || action, now(), d.id);
  notify(b.client_id, 'dispute', `اتحل نزاع حجز #${b.id}`, `booking:${b.id}`);
  notify(b.talent_id, 'dispute', `اتحل نزاع حجز #${b.id}`, `booking:${b.id}`);
  res.json({ ok: true });
});
app.post('/api/owner/verify-exceptional/:userId', auth, ownerOnly, (req, res) => {
  const { approve } = req.body || {};
  const u = getUser(+req.params.userId);
  if (!u || u.verify_status !== 'exceptional') return res.status(404).json({ error: 'طلب غير موجود' });
  if (approve) {
    const pioneer = db.prepare(`SELECT id FROM users WHERE verified=1 AND pioneer=1 AND city=? AND niche=?`).get(u.city, u.niche) ? 0 : 1;
    db.prepare(`UPDATE users SET verified=1, verify_status='verified', pioneer=?, boost_until=? WHERE id=?`).run(pioneer, now() + 7 * 24 * 3600 * 1000, u.id);
    notify(u.id, 'verification', 'مبروك! اتوافق على توثيقك في المراجعة الاستثنائية', '');
  } else {
    db.prepare(`UPDATE users SET verify_status='rejected', verify_reason='رفضته المراجعة الاستثنائية' WHERE id=?`).run(u.id);
    notify(u.id, 'verification', 'توثيقك الاستثنائي اترفض — راجع الكود وحاول تاني', '');
  }
  res.json({ ok: true });
});
app.post('/api/owner/users/:id/penalty', auth, ownerOnly, (req, res) => {
  const { level, frozen, banned } = req.body || {};
  const u = getUser(+req.params.id);
  if (!u) return res.status(404).json({ error: 'غير موجود' });
  db.prepare('UPDATE users SET penalty_level=COALESCE(?,penalty_level), frozen=COALESCE(?,frozen), banned=COALESCE(?,banned) WHERE id=?')
    .run(level ?? null, frozen != null ? (frozen ? 1 : 0) : null, banned != null ? (banned ? 1 : 0) : null, u.id);
  res.json({ ok: true });
});
/** Reject a false fee reference inside the 48h review window: reopens fee step + opens a dispute. */
app.post('/api/owner/bookings/:id/reject-fee', auth, ownerOnly, (req, res) => {
  const b = getBooking(+req.params.id);
  if (!b || b.fee_status !== 'confirmed') return res.status(400).json({ error: 'لا توجد عمولة مؤكدة' });
  if (now() - b.fee_confirmed_at > FEE_REVIEW_WINDOW_MS) return res.status(400).json({ error: 'انتهت نافذة مراجعة الـ48 ساعة' });
  db.prepare(`UPDATE payments SET status='rejected' WHERE booking_id=? AND kind='fee'`).run(b.id);
  db.prepare(`UPDATE bookings SET fee_status='rejected', prev_status=status, status='disputed' WHERE id=?`).run(b.id);
  db.prepare('INSERT INTO disputes (booking_id,opened_by,reason,created_at) VALUES (?,?,?,?)').run(b.id, req.user.id, 'مرجع عمولة خاطئ', now());
  notify(b.client_id, 'dispute', `حجز #${b.id}: اترفض مرجع العمولة واتفتح نزاع`, `booking:${b.id}`);
  res.json({ ok: true });
});

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'Deal standalone' }));
app.listen(PORT, () => console.log(`Deal standalone running on http://localhost:${PORT}`));
